﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter9_Exercise21
{
    public partial class Main : Form
    {
        int reverseCount = 0;
        string manualHelp = "Enter data into the input text box, separating numbers by commas.\r\nExample:  1,5,6,10,15";
        string randomHelp = "Random numbers (0-100) will be inserted into the array.  Number of elements is randomly chosen between 2 and 20.";

        public Main()
        {
            InitializeComponent();
            chart_ArrayFull.Series[0].Name = "Array Value";
            chart_ArrayHalf.Series[0].Name = "Array Value";
            chart_ArrayFull.Visible = false;
            chart_ArrayHalf.Visible = false;
        }

        private void radioButton_Manual_CheckedChanged(object sender, EventArgs e)
        {
            label_Help.Text = manualHelp;
            textBox_Input.ReadOnly = false;
            textBox_Input.Text = "";
        }

        private void radioButton_Random_CheckedChanged(object sender, EventArgs e)
        {
            label_Help.Text = randomHelp;
            textBox_Input.ReadOnly = true;
            int[] randomArray = randomizeArray();
            textBox_Input.Text = printArray(randomArray);
        }

        private void button_Reverse_Click(object sender, EventArgs e)
        {

            radioButton_Manual.Enabled = false;
            radioButton_Random.Enabled = false;

            if (reverseCount == 0)
            {
                chart_ArrayHalf.Visible = true;
                var arrayString = textBox_Input.Text.Replace(" ", "").Split(',');
                var arrayNumbers = parseArrayString(arrayString);
                label_Array.Text = printArray(arrayNumbers);
                var partialReversedArray = partialReverseArray(arrayNumbers);
                chart_ArrayHalf.Series[0].Points.DataBindY(partialReversedArray);
                textBox_Input.ReadOnly = true;
            }
            else if (reverseCount == 1)
            {
                chart_ArrayFull.Visible = true;
                var arrayString = textBox_Input.Text.Replace(" ", "").Split(',');
                var arrayNumbers = parseArrayString(arrayString);
                label_Array.Text = printArray(arrayNumbers);
                var fullyReversedArray = reverseArray(arrayNumbers);
                chart_ArrayFull.Series[0].Points.DataBindY(fullyReversedArray);
            }

            reverseCount++;
            button_Reverse.Enabled = checkReverseButton(reverseCount);
            button_Reverse.Text = updateReverseCount(reverseCount);
        }

        private void button_ResetAll_Click(object sender, EventArgs e)
        {
            chart_ArrayFull.Visible = false;
            chart_ArrayHalf.Visible = false;
            radioButton_Manual.Enabled = true;
            radioButton_Random.Enabled = true;
            reverseCount = 0;
            textBox_Input.Text = "";
            button_Reverse.Enabled = checkReverseButton(reverseCount);
            button_Reverse.Text = updateReverseCount(reverseCount);

            if (radioButton_Random.Checked == true)
            {
                textBox_Input.ReadOnly = true;
                int[] randomArray = randomizeArray();
                textBox_Input.Text = printArray(randomArray);
            }
            else
            {
                textBox_Input.ReadOnly = false;
            }
        }

        //Helper Methods
        static string printArray(int[] array)
        {
            string label = "";
            foreach (var item in array)
            {
                label += item;
                label += ",";
            }
            label = label.Remove(label.Length - 1);
            return label;
        }
        static int[] randomizeArray()
        {
            Random random = new Random();
            int totalValues = random.Next(2, 21);
            int[] array = new int[totalValues];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = random.Next(0, 101);
            }
            return array;
        }
        static int[] parseArrayString(string[] arrayString)
        {
            int[] arrayNumbers = new int[arrayString.Length];
            for (int i = 0; i < arrayString.Length; i++)
            {
                int.TryParse(arrayString[i], out arrayNumbers[i]);
            }
            return arrayNumbers;
        }

        static string updateReverseCount(int reverseCount)
        {
            string label = String.Format("Reverse ({0}/2)", reverseCount);
            return label;
        }

        static bool checkReverseButton(int reverseCount)
        {
            if (reverseCount == 2)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        static int[] partialReverseArray(int[] array)
        {
            Array.Reverse(array, 0, array.Length / 2);
            return array;
        }

        static int[] reverseArray(int[] array)
        {
            Array.Reverse(array);
            return array;
        }
    }
}
