﻿namespace Chapter9_Exercise21
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.radioButton_Random = new System.Windows.Forms.RadioButton();
            this.radioButton_Manual = new System.Windows.Forms.RadioButton();
            this.textBox_Input = new System.Windows.Forms.TextBox();
            this.label_Help = new System.Windows.Forms.Label();
            this.groupBox_Options = new System.Windows.Forms.GroupBox();
            this.groupBox_Input = new System.Windows.Forms.GroupBox();
            this.button_Reverse = new System.Windows.Forms.Button();
            this.groupBox_Help = new System.Windows.Forms.GroupBox();
            this.button_ResetAll = new System.Windows.Forms.Button();
            this.groupBox_FullChart = new System.Windows.Forms.GroupBox();
            this.chart_ArrayFull = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chart_ArrayHalf = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_Array = new System.Windows.Forms.Label();
            this.groupBox_Options.SuspendLayout();
            this.groupBox_Input.SuspendLayout();
            this.groupBox_Help.SuspendLayout();
            this.groupBox_FullChart.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_ArrayFull)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_ArrayHalf)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // radioButton_Random
            // 
            this.radioButton_Random.AutoSize = true;
            this.radioButton_Random.Location = new System.Drawing.Point(6, 42);
            this.radioButton_Random.Name = "radioButton_Random";
            this.radioButton_Random.Size = new System.Drawing.Size(92, 17);
            this.radioButton_Random.TabIndex = 2;
            this.radioButton_Random.TabStop = true;
            this.radioButton_Random.Text = "Random Input";
            this.radioButton_Random.UseVisualStyleBackColor = true;
            this.radioButton_Random.CheckedChanged += new System.EventHandler(this.radioButton_Random_CheckedChanged);
            // 
            // radioButton_Manual
            // 
            this.radioButton_Manual.AutoSize = true;
            this.radioButton_Manual.Location = new System.Drawing.Point(6, 19);
            this.radioButton_Manual.Name = "radioButton_Manual";
            this.radioButton_Manual.Size = new System.Drawing.Size(87, 17);
            this.radioButton_Manual.TabIndex = 1;
            this.radioButton_Manual.TabStop = true;
            this.radioButton_Manual.Text = "Manual Input";
            this.radioButton_Manual.UseVisualStyleBackColor = true;
            this.radioButton_Manual.CheckedChanged += new System.EventHandler(this.radioButton_Manual_CheckedChanged);
            // 
            // textBox_Input
            // 
            this.textBox_Input.Location = new System.Drawing.Point(6, 20);
            this.textBox_Input.Multiline = true;
            this.textBox_Input.Name = "textBox_Input";
            this.textBox_Input.Size = new System.Drawing.Size(123, 39);
            this.textBox_Input.TabIndex = 3;
            // 
            // label_Help
            // 
            this.label_Help.Location = new System.Drawing.Point(6, 16);
            this.label_Help.Name = "label_Help";
            this.label_Help.Size = new System.Drawing.Size(239, 45);
            this.label_Help.TabIndex = 4;
            // 
            // groupBox_Options
            // 
            this.groupBox_Options.Controls.Add(this.radioButton_Manual);
            this.groupBox_Options.Controls.Add(this.radioButton_Random);
            this.groupBox_Options.Location = new System.Drawing.Point(323, 12);
            this.groupBox_Options.Name = "groupBox_Options";
            this.groupBox_Options.Size = new System.Drawing.Size(107, 71);
            this.groupBox_Options.TabIndex = 5;
            this.groupBox_Options.TabStop = false;
            this.groupBox_Options.Text = "Options";
            // 
            // groupBox_Input
            // 
            this.groupBox_Input.Controls.Add(this.textBox_Input);
            this.groupBox_Input.Location = new System.Drawing.Point(439, 12);
            this.groupBox_Input.Name = "groupBox_Input";
            this.groupBox_Input.Size = new System.Drawing.Size(135, 71);
            this.groupBox_Input.TabIndex = 6;
            this.groupBox_Input.TabStop = false;
            this.groupBox_Input.Text = "Input";
            // 
            // button_Reverse
            // 
            this.button_Reverse.Location = new System.Drawing.Point(323, 89);
            this.button_Reverse.Name = "button_Reverse";
            this.button_Reverse.Size = new System.Drawing.Size(251, 23);
            this.button_Reverse.TabIndex = 7;
            this.button_Reverse.Text = "Reverse (0/2)";
            this.button_Reverse.UseVisualStyleBackColor = true;
            this.button_Reverse.Click += new System.EventHandler(this.button_Reverse_Click);
            // 
            // groupBox_Help
            // 
            this.groupBox_Help.Controls.Add(this.label_Help);
            this.groupBox_Help.Location = new System.Drawing.Point(323, 198);
            this.groupBox_Help.Name = "groupBox_Help";
            this.groupBox_Help.Size = new System.Drawing.Size(251, 64);
            this.groupBox_Help.TabIndex = 8;
            this.groupBox_Help.TabStop = false;
            this.groupBox_Help.Text = "Help";
            // 
            // button_ResetAll
            // 
            this.button_ResetAll.Location = new System.Drawing.Point(323, 169);
            this.button_ResetAll.Name = "button_ResetAll";
            this.button_ResetAll.Size = new System.Drawing.Size(251, 23);
            this.button_ResetAll.TabIndex = 11;
            this.button_ResetAll.Text = "Reset All";
            this.button_ResetAll.UseVisualStyleBackColor = true;
            this.button_ResetAll.Click += new System.EventHandler(this.button_ResetAll_Click);
            // 
            // groupBox_FullChart
            // 
            this.groupBox_FullChart.Controls.Add(this.chart_ArrayFull);
            this.groupBox_FullChart.Location = new System.Drawing.Point(13, 12);
            this.groupBox_FullChart.Name = "groupBox_FullChart";
            this.groupBox_FullChart.Size = new System.Drawing.Size(304, 250);
            this.groupBox_FullChart.TabIndex = 12;
            this.groupBox_FullChart.TabStop = false;
            this.groupBox_FullChart.Text = "Fully Reversed Chart";
            // 
            // chart_ArrayFull
            // 
            this.chart_ArrayFull.BorderlineColor = System.Drawing.Color.Black;
            this.chart_ArrayFull.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea5.Name = "ChartArea1";
            this.chart_ArrayFull.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart_ArrayFull.Legends.Add(legend5);
            this.chart_ArrayFull.Location = new System.Drawing.Point(7, 19);
            this.chart_ArrayFull.Name = "chart_ArrayFull";
            this.chart_ArrayFull.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chart_ArrayFull.Series.Add(series5);
            this.chart_ArrayFull.Size = new System.Drawing.Size(291, 225);
            this.chart_ArrayFull.TabIndex = 13;
            this.chart_ArrayFull.Text = "chart";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chart_ArrayHalf);
            this.groupBox1.Location = new System.Drawing.Point(583, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(304, 250);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Partially Reversed Chart";
            // 
            // chart_ArrayHalf
            // 
            this.chart_ArrayHalf.BorderlineColor = System.Drawing.Color.Black;
            this.chart_ArrayHalf.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea6.Name = "ChartArea1";
            this.chart_ArrayHalf.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chart_ArrayHalf.Legends.Add(legend6);
            this.chart_ArrayHalf.Location = new System.Drawing.Point(6, 19);
            this.chart_ArrayHalf.Name = "chart_ArrayHalf";
            this.chart_ArrayHalf.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series6.ChartArea = "ChartArea1";
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.chart_ArrayHalf.Series.Add(series6);
            this.chart_ArrayHalf.Size = new System.Drawing.Size(292, 225);
            this.chart_ArrayHalf.TabIndex = 15;
            this.chart_ArrayHalf.Text = "chart";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_Array);
            this.groupBox2.Location = new System.Drawing.Point(323, 115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(248, 48);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Array";
            // 
            // label_Array
            // 
            this.label_Array.Location = new System.Drawing.Point(6, 16);
            this.label_Array.Name = "label_Array";
            this.label_Array.Size = new System.Drawing.Size(236, 29);
            this.label_Array.TabIndex = 17;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 271);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox_FullChart);
            this.Controls.Add(this.button_ResetAll);
            this.Controls.Add(this.groupBox_Help);
            this.Controls.Add(this.button_Reverse);
            this.Controls.Add(this.groupBox_Input);
            this.Controls.Add(this.groupBox_Options);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Array Reverser";
            this.groupBox_Options.ResumeLayout(false);
            this.groupBox_Options.PerformLayout();
            this.groupBox_Input.ResumeLayout(false);
            this.groupBox_Input.PerformLayout();
            this.groupBox_Help.ResumeLayout(false);
            this.groupBox_FullChart.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_ArrayFull)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_ArrayHalf)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RadioButton radioButton_Random;
        private System.Windows.Forms.RadioButton radioButton_Manual;
        private System.Windows.Forms.TextBox textBox_Input;
        private System.Windows.Forms.Label label_Help;
        private System.Windows.Forms.GroupBox groupBox_Options;
        private System.Windows.Forms.GroupBox groupBox_Input;
        private System.Windows.Forms.Button button_Reverse;
        private System.Windows.Forms.GroupBox groupBox_Help;
        private System.Windows.Forms.Button button_ResetAll;
        private System.Windows.Forms.GroupBox groupBox_FullChart;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_ArrayFull;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_ArrayHalf;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_Array;
    }
}

